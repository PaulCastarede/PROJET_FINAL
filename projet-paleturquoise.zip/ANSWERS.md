Semaine 3 :

Q: Comment avez-vous conçu la lecture du fichier ? Comment l'avez-vous structurée de sorte à pouvoir la tester de manière efficace ?
A: On parcourt chaque caractère de chaque ligne du txt à partir des trois tirets '---'.
Dès lors qu'un caractère consacré est rencontré, on ajoute le sprite correspondant à la sprite_list associée, à la position de la colonne et de la ligne multipliée par un facteur pour qu'elle corresponde aux coordonnées in game adéquates.
Pour la tester de manière efficace, on en a fait une fonction qui prend n'importe quelle str en argument, et lit le txt correspondant s'il se trouve dans le dossier map. On peut ainsi mettre nos maps tests dans le dossier maps.
...
Depuis l'utilisation de la bibliotheque YAML, on lit décompose le fichier en plusieurs partie : tout d'abord on lit jusqu'à la premiere "---" que YAML détecte automatiquement le type, puis on décompose les lignes suivante sous formes de listes de listes de str, en effectuant des verifications pour les dimensions, interrupteurs et portails

Q: Comment avez-vous adapté vos tests existants au fait que la carte ne soit plus la même qu'au départ ? Est-ce que vos tests résisteront à d'autres changements dans le futur ? Si oui, pourquoi ? Si non, que pensez-vous faire plus tard ?
Nous n'avions pas encore écrit de tests au moment de cetet extension dans notre jeu :(. Nos tests résisteront probablement à d'autres changements dans le future puisqu'ils sont définis de manière suffisament large et en utilisant des maps spécifiques appropriées qui devraient résister aux modifications futures.

Q: Le code qui gère la lave ressemble-t-il plus à celui de l'herbe, des pièces, ou des blobs ? Expliquez votre réponse.
A: Le code qui gère la lave s'inspire de celui de l'herbe et de celui des blobs. Il ressemble à l'herbe car on l'a défini comme un sprite qui devait rester toujours à la même position, comme un élément du terrain (avec use_spatial_hash=True), mais partage la même condition que le slime de tuer la joueuse si elle entre en collision avec. On a utilisé la boucle conditionnelle 
if collided_no_go or  collided_slimes   :    #Si le joueur est en collision avec la lave ou un monstre...
     self.death = True

Q: Comment détectez-vous les conditions dans lesquelles les blobs doivent changer de direction ?
A: J'ai défini un sprite invisibile 'front' qui se situe à chaque instant juste devant le blob, et un autre, 'below' qui se situe juste en dessous de lui. Dès lors que le sprite 'front' entre en collision avec un element du terrain (wall), ou dès lors que le sprite 'below' n'est plus en collision avec un élément du terrain (wall), le slime change de direction (slime.change_x *= -1 ) 


Semaine 4 :

Q: Quelles formules utilisez-vous exactement pour l'épée ? Comment passez-vous des coordonnées écran aux coordonnées monde ?
A: Pour calculer l'angle entre le joueur et la position de la souris dans le monde, on utilise : math.atan2(self.world_y - self.world.player_sprite.center_y, self.world_x - self.world.player_sprite.center_x) , car dans un triangle rectangle tan = coté opposé / côté adjacent , donc en utilisant la fonction arctan de cette expression nous avons l'angle formé par le triangle.

Q:Comment testez-vous l'épée ? Comment testez-vous que son orientation est importante pour déterminer si elle touche un monstre ?
A:On teste l'épée dans le fichier test_monsters.py, et durant la séance d'implémentation , nous avons implémenté une fonctionnalité qui change le côté de maintien de l'épée en fonction d'un certain plus à gauche ou à droite. En réalisant cela, nous avons remarqué que l'orientation n'avait pas un certain impact, mais plutôt la position.

Q: Comment transférez-vous le score de la joueuse d'un niveau à l'autre ? Où le remettez-vous à zéro ?
A: Le score est un attribut de la joueuse. De plus, la classe World qui correspond au niveau a une méthode clear() qui admet un setting clear_player qui peut etre True ou False. Lors du passage d'un niveau à l'autre, ce setting est False, et la joueuse reste avec ses attributs. En revanche, lorsque l'on veut "hard reset" pour un gameover ou lorsque l'on appuie sur 'esc' par exemple, le setting "clear_player" est True, supprimant la joueuse en meme temps que son score.

Q: Avez-vous du code dupliqué entre les cas où la joueuse perd parce qu'elle a touché un ou monstre ou de la lave ?
A: La classe Player a une méthode dies() implémentée comme suit :
if no_go_touched or monsters_touched or self.center_y < -64:
            self.lives -= 1
            ...
ou no_go_touched et monsters_touched sont les éléments en collision avec le joueur. Il y a du code dupliqué dans le sens où on applique deux fois arcade.check_for_collision pour obtenir les deux listes no_go_touched et monsters_touched, mais la défaite en elle-même est gérée au même endroit.

Q: Comment modélisez-vous la "next-map" ? Où la stockez-vous, et comment la traitez-vous quand la joueuse atteint le point E 
A: La next-map est simplement une valeur string, correspondant au nom du fichier .txt, qui est lue de la même façon que les ints de heigth et width dans la fonction readmap, et stockée dans le str "Next-map". Lorsque la joueuse atteint le point E, on appelle alors la fonction readmap, mais en prenant en argument le str "Next_map" (on a pour cela changé les paramètres de la fonction readmap et adapté son code pour que le chemin d'accès du fichier corresponde au nouveau paramètre map).

Q : Que se passe-t-il si la joueuse atteint le E mais la carte n'a pas de next-map ?
A : Si la carte n'a pas de next map, on considère que le niveau est le dernier niveau et une variable bool "last_level", True par défaut, reste True. Ainsi, si le joueur atteint le E alors que last_level a pour valeur True, le booléen "Victory" devient true (ce qui fait apparaître un message à l'écran, et peut être à l'avenir une musique spécifique) (update : voir alt_game_views.endgame).


Semaine 5 :

Q: Quelles formules utilisez-vous exactement pour l'arc et les flèches ?
Pour l'arc, on utilise les mêmes formules que le déplacement de l'épée, puisqu'ils ont en réalité le même déplacement. Pour les flèches, avant d'être relachées, elles suivent la même formule pour l'angle que les armes à un angle constant de décalage près, mais leur position est calculée en fonction de la position de l'arc, et non plus du joueur comme c'était le cas pour l'épée et l'arc. Ensuite, une fois relachée, la flèche part avec une vitesse initiale verticale speed * cos(angle) et une vitesse horizontale initiale speed * cos(angle) (ce qui correspondrait à la réalité physique en appliquant les projections sur des axes x et y). Ensuite, la vitesse de la flèche décroit à chaque tick d'une valeur égale à une constante de gravité (qui lui est propre). On reconnaît la la 2ème loi de Newton avec la seule force de gravité : g = a.
Pour l'orientation de la flèche, on a trouvé (par un calcul trigonométrique qu'on vous épargnera bien que pas si compliqué) 
angle = math.degrees(math.acos(self.change_y/(math.sqrt((self.change_x)**2 +(self.change_y)**2)))) -45 
lorsque la flèche va vers la droite, 
self.angle = math.degrees(math.asin(self.change_y/(math.sqrt((self.change_x)**2 +(self.change_y)**2)))) +225
lorsque la flèche va vers la gauche.


Q : Quelles formules utilisez-vous exactement pour le déplacement des chauves-souris (champ d'action, changements de direction, etc.) ?
A : J'ai d'abord défini une classe "Bat" à laquelle j'ai attribué un point d'apparition fixe et un angle "theta" qui représente l'orientation de sa direction.
Pour gérer le champ d'action de la chauve souris, j'ai écrit une boucle conditionnelle qui ajoute pi a theta lorsqu'elle dépasse une certaine distance (200 pixels) de son point d'apparition. Elle fait ainsi demi-tour lorsqu'elle sort d'un cercle de rayon 200 centré en son point d'apparition.  J'ai aussi fait en sorte que la boucle ne puisse pas s'exécuter dans un laps de temps trop court, auquel cas la chauve souris pouvait rester en dehors de son cercle d'action à faire des demi-tours indéfiniment.
Pour que le mouvement de la chauve souris soit erratique, j'ai fait en sorte que tous les 15 ticks, le theta de la chauve souris soit redéfini de manière aléatoire suivant une distribution normale centrée en la précédente valeur de theta et avec un écart type de pi/10.


Q: Comment avez-vous structuré votre programme pour que les flèches puissent poursuivre leur vol ?
A: Dès que le boutton droit de la souris est relâché, nous ajoutons l'arrow à une liste arrow_sprite_list. J'ai défini une méthode arrows_movement() de Arrow appelée à chaque on_update() sur tous les éléments de arrow_sprite_list, qui gère la gestion du déplacement d'une flèche relâchée (donc toutes celles dans arrow_sprite_list), puis vérifie si la flèche est en collision avec un wall, auquel cas elle l'enlève de la liste arrow_sprite_list.


Q: Comment gérez-vous le fait que vous avez maintenant deux types de monstres, et deux types d'armes ? Comment faites-vous pour ne pas dupliquer du code entre ceux-ci ?
A: Pour les monstres, on a créé une classe abstraite monstre et deux sous-classes 'Slime' et 'Bat' qui héritent de cette classe abstraite. On a ainsi pu mettre les blobs et les chauve-souris dans une même liste 'monsters_list'. Les propriétés qui concernent ces deux monstres s'appliquent sur tous les éléments de la liste monsters, et chaque sous classe de type de monstre définit les méthodes qui sont propres au monstre. Par exemple, les slimes et les chauve souris héritent d'une même classe abstraite 'movement', mais qui est ensuite spécifiée différemment pour chaque type de monstre. Pour les armes, le procédé était à peu près similaire mais la classe Weapon dont elles héritent n'est pas abstraite et définit le gros des méthodes que les armes utilisent, ayant plus de similitudes dans leur comportement (la seule différence intrinsèque étant que l'épée tue les monstres en collision)


Semaine 10:

Q: Quel algorithme utilisez-vous pour identifier tous les blocs d’une plateformes, et leurs limites de déplacement ?
A: J'utilise un algorithme récursif de pattern matching. Dans la fonction readmap, je parcours une première fois les caractères de la map pour détecter les blocs de plateforme. Dès qu'une flèche est rencontrée, readmap fait appel à une fonction récursive detect_block qui ajoute tous les sprites appartenant à un même bloc de plateformes et leur donne les mêmes limites de déplacement représentées par la dataclass "trajectory". En fonction du caractère rencontré,  Les limites de déplacement sont déterminées par la longueur des séries de flèches qui partent du bloc de plateformes

Q:Sur quelle structure travaille cet algorithme ? Quels sont les avantages et inconvénients de votre choix ?
A: Cet algorithme travaille sur la liste de liste (ou "matrice") qui correspond à la map en y enlevant les caractères considérés comme faisant partie d'un bloc de plateformes. Il agit également sur les listes moving_platforms_list et d'autres SpriteLists de World en y ajoutant au fur et à mesure les sprites considérés comme des plateformes avant d'effacer le caractère associé à la map.
L'avantage d'agir directement sur la matrice de caractères qui représente la map en effacant les caractères au fur et à mesure est de garantir qu'on ajoute pas deux fois un même sprite a la liste de plateformes, mais aussi que l'algorithme ne cycle pas, puisque detect_block ne fait rien lorsqu'il rencontre un espace.  
---
En y repensant, j'ai réalisé que la question faisait probablement référence à l'utilisation d'un set pour s'assurer que l'on n'ajoute pas plusieurs fois la meme plateforme dans un bloc, ou encore a des dict pour associer un sprite de plateforme au bloc correspondant. Notre algorithme n'utilise aucun de ces deux éléments, et sa structure elle-même aurait rendu difficile l'utilisation d'une de ces solutions. Peut-être qu'un autre algorithme les utilisant aurait été plus satisfaisant et élégant, mais j'estime celui que l'on a choisi tout de même convenable, son principal défaut étant peut-être le nombre d'arguments que la fonction detect_block utilise.

Q:Quelle bibliothèque utilisez-vous pour lire les instructions des interrupteurs ? Dites en une ou deux phrases pourquoi vous avez choisi celle-là.

A:Nous avons décidé d'utiliser Pyyaml pour sa simplicité. Elle détécte automatiquement les dictionnaires dans la partie config (avant --- ), et nous retourne un dictionnaires avec des clés de types str 
Par exemple : map1.txt nous avons les clés de types str (weight, height, next-map, switches, gates) ; et des valeurs de différents types  (int, int, str, list[dict], dict) (Raison pour laquelle nous avons mis Any).
L'avantage est qu'une fois dans le dictionnaire config, on peut accéder à n'importe quelle élément (et ainsi dans les dict de Switch et aussi Gates)


Q:Comment votre design général évolue-t-il pour tenir compte des interrupteurs et des portails ?
A:Nous avons rencontré des difficultés pour modéliser les dictionnaires d'actions, nous avons donc décidé de "hard-coder" et omettre le type pour les dictionnaires de la partie config. En revanche pour le reste, nous avons créée deux classes : -Switch qui hérite de classe Collidable Platform (car c'est une plateforme mobile), et une classe Gate statique.